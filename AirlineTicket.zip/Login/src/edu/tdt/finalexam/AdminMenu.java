/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.tdt.finalexam;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Trương Kiều Phương
 */
public class AdminMenu extends javax.swing.JFrame {

    Login login;
    AddFlight add;
    search_flight search;
    RemoveFlight remove;
    ListCustomer cus;
    AddRunway runway;
    AddTicket ticket;
    RemoveRunway rerunway;
    RemoveTicket reticket;
    private final String url = "jdbc:postgresql://localhost:5433/FinalExamBD";
    private final String user = "postgres";
    private final String password = "123"; 
    
    /**
     * Creates new form AdminMenu
     */
    // Quay lại login
    public AdminMenu(Login login1) {
        login = login1;
        login1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
    
    //
    public AdminMenu(AddFlight add1) {
        add = add1;
        add1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
    
    //Search flight return
    public AdminMenu(search_flight search1) {
        search = search1;
        search1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
    
    // Remove Flight return
     public AdminMenu(RemoveFlight remove1) {
        remove = remove1;
        remove1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
    
     // Đến list customer
     public AdminMenu(ListCustomer login1) {
        cus = login1;
        login1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
     
     // add runway
      public AdminMenu(AddRunway login1) {
        runway = login1;
        login1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
    // return ticket
      public AdminMenu(AddTicket add1) {
        ticket = add1;
        add1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
      // Click remove runway
      public AdminMenu(RemoveRunway login1) {
        rerunway = login1;
        login1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
      
      
      // Remove ticket button
      public AdminMenu(RemoveTicket add1) {
        reticket = add1;
        add1.setVisible(false);
        
        initComponents();
        
        this.setLocationRelativeTo(null);
        try
        {
            Class .forName("com.postgres.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url,user,password);
        }
        catch(Exception e)
        {
         System.out.println(e.getMessage());
        }
    }
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Admin Menu");

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Add Flight");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Remove Flight");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Add Runway");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Remove Runway");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton7.setText("List Customer information");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("Add Ticket");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("Remove Ticket");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton8)
                    .addComponent(jButton9))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        search_flight flight = new search_flight(this);
        flight.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        AddFlight flight = new AddFlight(this);
        flight.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        RemoveFlight remove = new RemoveFlight(this);
        remove.setVisible(true);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        ListCustomer cus = new ListCustomer(this);
        cus.setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        AddRunway runway = new AddRunway(this);
        runway.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        AddTicket runway = new AddTicket(this);
        runway.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         RemoveRunway runway = new RemoveRunway(this);
        runway.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        RemoveTicket runway = new RemoveTicket(this);
        runway.setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    /**
     * @param args the command line arguments
     */
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
